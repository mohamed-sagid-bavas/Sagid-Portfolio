# Mohamed Sagid Bavas N — Digital Portfolio

A responsive static portfolio website built with HTML, CSS and JavaScript.

## Files
- `index.html` — page content
- `style.css` — layout, colors and responsive styling
- `script.js` — mobile navigation, reveal animations and current year

## Run locally
1. Extract the ZIP file.
2. Open the `digital_portfolio` folder.
3. Double-click `index.html` to preview it in your browser.

## Publish with GitHub Pages
1. Create a public repository, for example `mohamed-sagid-bavas-portfolio`.
2. Upload `index.html`, `style.css` and `script.js` to the repository root.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then click **Save**.
6. Wait for the Pages deployment to finish and use the **Visit site** link shown in Settings → Pages.

GitHub Pages publishes static HTML, CSS and JavaScript. A project site normally uses:
`https://mohamed-sagid-bavas.github.io/REPOSITORY-NAME/`

## Before publishing
Review and update your contact details, project descriptions, course title and any dates so the site is fully accurate. Public portfolio pages expose the contact details you choose to publish.
